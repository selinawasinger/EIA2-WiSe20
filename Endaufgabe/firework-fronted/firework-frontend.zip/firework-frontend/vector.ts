namespace firework {
  // vector interface for position
 export interface Vector {
    x: number;
    y: number;
  }
}